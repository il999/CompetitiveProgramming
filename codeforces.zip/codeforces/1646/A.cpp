#include <bits/stdc++.h>
using namespace std;
void solve()
{
    long long n;
    long long s;
    cin>>n>>s;
    cout<<s/(n*n)<<"\n";
}
int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);
    int t;
    cin>>t;
    while(t--)
        solve();
}
