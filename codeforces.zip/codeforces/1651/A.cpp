#include <bits/stdc++.h>

using namespace std;
void solve()
{
    int n;
    cin>>n;
    int winner=(1<<(n))-1;
    cout<<winner<<"\n";
}
int main()
{
    int t;
    cin>>t;
    while(t--)
        solve();
}
