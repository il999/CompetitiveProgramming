#include <iostream>
#include <bits/stdc++.h>
using namespace std;
void solve()
{
    long long a,b;
    cin>>a>>b;
    cout<<-(a*a)<<" "<<b*b<<endl;

}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }
}
