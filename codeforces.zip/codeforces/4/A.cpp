#include <iostream>

using namespace std;

int main()
{
    int n=0;
    cin>>n;
    if(n%2>0 || n<=2)
    {
        cout<<"NO";

    }else
    {
        cout<<"YES";
    }

}

